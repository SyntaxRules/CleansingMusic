angular.module('cleansingMusic')

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {
  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})

.controller('PlaylistsCtrl', function($scope) {
  $scope.playlists = [
    { title: '50\'s Bop', id: 1 },
    { title: '60\'s Pop', id: 2 },
    { title: '70\'s Rock', id: 3 },
    { title: '80\'s Thrill', id: 4 },
    { title: '90\'s Cill', id: 5 },
    { title: '2000\'s Mil', id: 6 },
    { title: 'Classically', id: 7 },
    { title: 'Inspirational', id: 8 },
    { title: 'Beyond Words', id: 9 },
    { title: 'Country Comfort', id: 10 },
    { title: 'Off Track', id: 11 },
    { title: 'Mixup', id: 12 },
    { title: 'Christmas', id: 13 }
  ];
})

.controller('PlaylistCtrl', function($scope, $stateParams, $cordovaMedia) {
    var src = "/scs.mp3";

    var mediaSource = $cordovaMedia.newMedia(src);
    var promise = mediaSource.promise;
    var mediaStatus = mediaSource.mediaStatus;
    var media = mediaSource.media;

    $cordovaMedia.play(media);
});
